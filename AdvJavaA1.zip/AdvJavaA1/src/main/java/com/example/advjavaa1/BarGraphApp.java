package com.example.advjavaa1;//defining package

//imported java classes n libraries
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class BarGraphApp extends Application {//extends application from javafx to make it java fx application

    private final TableView<SalesData> tableView = new TableView<>(); //this displays the data from the database in table format
    private Scene barChartScene; //create scene for the barchart

    public static void main(String[] args) {
        launch(args);
    }
    //this lauches the application

    @Override
    public void start(Stage primaryStage) {   //this method is for startinng the application
        BorderPane root = new BorderPane();   //it's the arangement of content
        root.getStyleClass().add("border-pane"); //adds css style to borderpane. its like giving id

        Image icon = new Image(Objects.requireNonNull(getClass().getResourceAsStream("/micon.png")));
        primaryStage.getIcons().add(icon);
        // adds icon to the java fx application


        // this code set creates the bar graph
        CategoryAxis xAxis = new CategoryAxis();
        NumberAxis yAxis = new NumberAxis();
        BarChart<String, Number> barChart = new BarChart<>(xAxis, yAxis);
        barChart.setTitle("MARK'S SALES"); //this is the heading
        xAxis.setLabel("Month"); // x axis label for the graph set as month
        yAxis.setLabel("Sales in USD"); // y axis label for the graph set as sales

        //gets the data from database and puts it in the graph
        List<SalesData> salesDataList = getDataFromDatabase();
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        for (SalesData data : salesDataList) {
            series.getData().add(new XYChart.Data<>(data.getMonth(), data.getSales()));
        }
        barChart.getData().add(series); // this code adds the series to the barchart

        // this code set creates a button called show table view which swiches the graph data into a table
        Button showTableButton = new Button("Show Table View");
        showTableButton.getStyleClass().add("button");//giving the button a id for styling
        showTableButton.setOnAction(e -> showTableView(primaryStage)); //to switch on clicking the button

        VBox vBox = new VBox(barChart, showTableButton); //vertical presentation of contents
        vBox.getStyleClass().add("vbox"); // giving id to style in css

        root.setCenter(vBox); //align centre

        barChartScene = new Scene(root, 800, 600);
        barChartScene.getStylesheets().add(Objects.requireNonNull(getClass().getResource("/styles.css")).toExternalForm()); //linking the stylesheet (css file)

        primaryStage.setTitle("Marks Total Sales in a Year"); //application title
        primaryStage.setScene(barChartScene);
        primaryStage.show();
        //sets and displpays the scene
    }

    private List<SalesData> getDataFromDatabase() {     //gets data from the sql database
        List<SalesData> salesDataList = new ArrayList<>(); //stores the data
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/Marks_sales", "root", "MySQL@3014");  // establish connection between the app and the database
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT month, sales FROM salestable"); //method of executing sql statements

            while (resultSet.next()) { //to run while the try statement is executed
                String month = resultSet.getString("month"); //to get month data and set label as month
                double sales = resultSet.getDouble("sales"); //to get sales data and set label as sales
                salesDataList.add(new SalesData(month, sales));   //adds each rowto list
            }

            //closes the database resources
            resultSet.close();
            statement.close();
            connection.close();
        }

        catch (Exception e) {
            e.printStackTrace();
        }

        return salesDataList;
    }

    private void showTableView(Stage primaryStage) {      // switches the view to a table displaying the sales data
        tableView.getColumns().clear();  //clears already existing columns
        tableView.getStyleClass().add("table-view"); ///setting id to style the columns

        //gets data from sql database and displays it in table with label month and given it an id inorder to style ut
        TableColumn<SalesData, String> monthColumn = new TableColumn<>("Month");
        monthColumn.setCellValueFactory(new PropertyValueFactory<>("month"));
        monthColumn.getStyleClass().add("table-column-header");//setting id to style the column header

        //get data from the database and displays it in table labelled sales
        TableColumn<SalesData, Double> salesColumn = new TableColumn<>("Sales");
        salesColumn.setCellValueFactory(new PropertyValueFactory<>("sales"));
        salesColumn.getStyleClass().add("table-column-header");

        //adds columns
        tableView.getColumns().add(monthColumn);
        tableView.getColumns().add(salesColumn);

        tableView.getItems().setAll(getDataFromDatabase());

        //onclicking button switches to graph
        Button showGraphButton = new Button("Show Graph View");
        showGraphButton.getStyleClass().add("button");
        showGraphButton.setOnAction(e -> primaryStage.setScene(barChartScene));


        VBox vBox = new VBox(tableView, showGraphButton);
        vBox.getStyleClass().add("vbox");
        Scene tableViewScene = new Scene(vBox, 800, 600);
        tableViewScene.getStylesheets().add(Objects.requireNonNull(getClass().getResource("/styles.css")).toExternalForm());

        primaryStage.setScene(tableViewScene);
    }

    public static class SalesData {
        private final String month;
        private final double sales;

        public SalesData(String month, double sales) {  //assigns parameters
            this.month = month;
            this.sales = sales;
        }

        public String getMonth() { //returns the values of month field
            return month;
        }

        public double getSales() {  //returns the values of sales field
            return sales;
        }
    }
}