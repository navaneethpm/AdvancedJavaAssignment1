package com.example.advjavaa1; //declaring package

//imported classes and libraries
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class SalesController {

    @FXML
    private BarChart<String, Number> barChart;

    @FXML
    private TableView<SalesData> tableView;

    @FXML
    private TableColumn<SalesData, String> monthColumn;

    @FXML
    private TableColumn<SalesData, Integer> salesColumn;

    @FXML
    public void initialize() {

        ObservableList<SalesData> data = FXCollections.observableArrayList(
                new SalesData("January", 50),
                new SalesData("February", 80),
                new SalesData("March", 65),
                new SalesData("April", 90)
        );

        // Set up bar chart
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        for (SalesData salesData : data) {
            series.getData().add(new XYChart.Data<>(salesData.getMonth(), salesData.getSales()));
        }
        barChart.getData().add(series);

        // Set up table columns
        monthColumn.setCellValueFactory(new PropertyValueFactory<>("month"));
        salesColumn.setCellValueFactory(new PropertyValueFactory<>("sales"));

        // Add data to table
        tableView.setItems(data);
    }

    @FXML
    private void showTableData(ActionEvent event) {
        tableView.setVisible(true);
    }

    public static class SalesData {
        private final String month;
        private final int sales;

        public SalesData(String month, int sales) {
            this.month = month;
            this.sales = sales;
        }

        public String getMonth() {
            return month;
        }

        public int getSales() {
            return sales;
        }
    }
}
