module com.example.advjavaa1 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.example.advjavaa1 to javafx.fxml;
    exports com.example.advjavaa1;
}